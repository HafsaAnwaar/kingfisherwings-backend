import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

@Injectable()
export class RedisService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(RedisService.name);
  private client: Redis;

  constructor(private readonly config: ConfigService) {}

  onModuleInit() {
    this.client = new Redis({
      host: this.config.get<string>('redis.host', 'localhost'),
      port: this.config.get<number>('redis.port', 6379),
      password: this.config.get<string>('redis.password') || undefined,
      db: this.config.get<number>('redis.db', 0),
      retryStrategy: (times) => Math.min(times * 100, 3000),
      enableReadyCheck: true,
      maxRetriesPerRequest: 3,
      lazyConnect: false,
    });

    this.client.on('connect', () => this.logger.log('Redis connected'));
    this.client.on('error', (e) => this.logger.error('Redis error', e));
    this.client.on('reconnecting', () => this.logger.warn('Redis reconnecting'));
  }

  async onModuleDestroy() {
    await this.client.quit();
  }

  getClient(): Redis {
    return this.client;
  }

  // ── Cache helpers ─────────────────────────────────────────

  async get<T>(key: string): Promise<T | null> {
    const val = await this.client.get(key);
    return val ? JSON.parse(val) : null;
  }

  async set(key: string, value: any, ttlSeconds?: number): Promise<void> {
    const serialized = JSON.stringify(value);
    if (ttlSeconds) {
      await this.client.setex(key, ttlSeconds, serialized);
    } else {
      await this.client.set(key, serialized);
    }
  }

  async del(...keys: string[]): Promise<void> {
    if (keys.length) await this.client.del(...keys);
  }

  async exists(key: string): Promise<boolean> {
    return (await this.client.exists(key)) === 1;
  }

  async ttl(key: string): Promise<number> {
    return this.client.ttl(key);
  }

  // ── Tenant-scoped key helpers ─────────────────────────────

  tenantKey(tenantId: string, ...parts: string[]): string {
    return `t:${tenantId}:${parts.join(':')}`;
  }

  userKey(tenantId: string, userId: string, ...parts: string[]): string {
    return `t:${tenantId}:u:${userId}:${parts.join(':')}`;
  }

  // ── Session management ────────────────────────────────────

  async setRefreshToken(
    tenantId: string,
    userId: string,
    tokenHash: string,
    ttlSeconds: number,
  ): Promise<void> {
    const key = this.userKey(tenantId, userId, 'refresh');
    await this.client.setex(key, ttlSeconds, tokenHash);
  }

  async getRefreshToken(tenantId: string, userId: string): Promise<string | null> {
    return this.client.get(this.userKey(tenantId, userId, 'refresh'));
  }

  async deleteRefreshToken(tenantId: string, userId: string): Promise<void> {
    await this.client.del(this.userKey(tenantId, userId, 'refresh'));
  }

  async blacklistToken(jti: string, ttlSeconds: number): Promise<void> {
    await this.client.setex(`blacklist:${jti}`, ttlSeconds, '1');
  }

  async isTokenBlacklisted(jti: string): Promise<boolean> {
    return this.exists(`blacklist:${jti}`);
  }

  // ── Cache-aside pattern ───────────────────────────────────

  async getOrSet<T>(key: string, factory: () => Promise<T>, ttlSeconds: number): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached !== null) return cached;

    const fresh = await factory();
    await this.set(key, fresh, ttlSeconds);
    return fresh;
  }

  // ── Pattern-based invalidation ────────────────────────────

  async invalidatePattern(pattern: string): Promise<void> {
    const keys = await this.client.keys(pattern);
    if (keys.length) {
      await this.client.del(...keys);
      this.logger.debug(`Invalidated ${keys.length} keys matching: ${pattern}`);
    }
  }

  async invalidateTenant(tenantId: string): Promise<void> {
    await this.invalidatePattern(`t:${tenantId}:*`);
  }
}
