# ADR-001: Single-DB Multi-Tenancy with PostgreSQL RLS

**Status:** Accepted  
**Date:** Week 0, Day 1

## Decision
Single PostgreSQL database. Every tenant-scoped table carries `tenant_id UUID NOT NULL`. RLS is enabled at the database layer — never at application level.

## Policy pattern
```sql
ALTER TABLE <table> ENABLE ROW LEVEL SECURITY;
ALTER TABLE <table> FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON <table>
  USING (tenant_id = current_tenant_id())
  WITH CHECK (tenant_id = current_tenant_id());
```

## Session context
The application sets `app.tenant_id` per connection via:
```sql
SELECT set_tenant_context('<uuid>');
```
`current_tenant_id()` reads this setting. The Prisma middleware calls this before every query.

## Consequences
- A bug in application code cannot leak cross-tenant data — the DB rejects it.
- `tenants` table is excluded from RLS (SUPER_ADMIN only).
- `prisma.forTenant(tenantId)` is the only way to get a scoped client.
- `prisma.unsafeBypassRLS` is restricted to tenant management and seeding.
