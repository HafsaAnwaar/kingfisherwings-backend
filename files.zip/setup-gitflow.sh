#!/usr/bin/env bash
set -e
REPO_URL="${1:-}"
if [ -z "$REPO_URL" ]; then
  echo "Usage: ./scripts/setup-gitflow.sh git@github.com:YOUR_ORG/freight-erp-backend.git"
  exit 1
fi
echo "==> Initialising Git"
git init
git remote add origin "$REPO_URL"
git add .
git commit -m "chore: initial project scaffold — NestJS + Prisma + Docker + CI"
git branch -M main
git push -u origin main
echo "==> Creating develop branch"
git checkout -b develop
git push -u origin develop
echo ""
echo "Gitflow ready. Branches: main (protected) + develop (protected)"
echo "Feature: git checkout -b feature/TICKET-description"
echo "Hotfix:  git checkout -b hotfix/description (from main)"
