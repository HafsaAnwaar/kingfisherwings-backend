/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Injectable, OnModuleInit, OnModuleDestroy, Logger,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);
  private __currentTenantId: string | null = null;

  constructor() {
    super({
      log: [
        { emit: 'stdout', level: 'info'  },
        { emit: 'stdout', level: 'warn'  },
        { emit: 'stdout', level: 'error' },
      ],
    });

    // RLS middleware: inject tenant context before every query
    this.$use(async (params: any, next: any) => {
      if (this.__currentTenantId) {
        await this.$executeRawUnsafe(
          `SELECT set_config('app.tenant_id', '${this.__currentTenantId}', TRUE)`,
        );
      }
      return next(params);
    });
  }

  async onModuleInit() {
    await this.$connect();
    this.logger.log('Database connected');
  }

  async onModuleDestroy() {
    await this.$disconnect();
    this.logger.log('Database disconnected');
  }

  /**
   * Returns a tenant-scoped Prisma client.
   * Every query sets app.tenant_id — RLS policies enforce isolation at DB layer.
   *
   * @example
   *   const db = this.prisma.forTenant(user.tenantId);
   *   const jobs = await db.job.findMany(); // Only this tenant's rows returned
   */
  forTenant(tenantId: string): this {
    const scoped = Object.create(this) as this;
    (scoped as any).__currentTenantId = tenantId;
    return scoped;
  }

  /**
   * Bypass RLS. SUPER_ADMIN and seeding only.
   * Do NOT use in service layer code.
   */
  get unsafeBypassRLS(): this {
    const scoped = Object.create(this) as this;
    (scoped as any).__currentTenantId = null;
    return scoped;
  }
}
