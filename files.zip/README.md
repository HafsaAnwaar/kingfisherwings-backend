# Fresa Gold — Freight ERP Backend

**NestJS + PostgreSQL (RLS) + Redis + Docker**  
**Client:** Kingfisher Wings Logistic LLC  
**MVP Scope:** Air Export + Sea FCL Export/Import

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Runtime | Node.js v20 LTS |
| Framework | NestJS |
| ORM | Prisma |
| Database | PostgreSQL 16 + Row-Level Security |
| Cache / Queue | Redis 7 + BullMQ |
| Containers | Docker + Docker Compose |
| Auth | JWT (access 15m + refresh 7d) |
| CI/CD | GitHub Actions |

---

## Multi-Tenancy Architecture

Single PostgreSQL database. Every table has `tenant_id UUID NOT NULL`. RLS policies enforced at DB layer.

```sql
-- Policy on every table (applied via migration 0000_init):
CREATE POLICY tenant_isolation ON <table>
  USING (tenant_id = current_tenant_id())
  WITH CHECK (tenant_id = current_tenant_id());
```

**Never use** raw Prisma client directly in services. Always use:
```typescript
// In any service:
const db = this.prisma.forTenant(user.tenantId);
const jobs = await db.job.findMany();  // RLS enforced automatically
```

---

## Branch Strategy (Gitflow)

| Branch | Purpose | Protection |
|--------|---------|-----------|
| `main` | Production only | PR + 1 approval required |
| `develop` | Integration | PR + 1 approval required |
| `feature/TICKET-description` | New features | Branch from develop |
| `hotfix/description` | Emergency fixes | Branch from main |

```bash
# Feature workflow
git checkout develop && git pull origin develop
git checkout -b feature/KFW-42-air-export-booking
# ... work ...
git push origin feature/KFW-42-air-export-booking
# Open PR → develop
```

---

## Local Setup

```bash
# 1. Clone and install
git clone git@github.com:YOUR_ORG/freight-erp-backend.git
cd freight-erp-backend
npm install

# 2. Environment
cp .env.example .env
# Edit .env with your local values

# 3. Start infrastructure
docker compose -f docker/docker-compose.yml up -d

# 4. Run migrations + seed
npx prisma migrate dev --name init
npx prisma db seed

# 5. Start dev server
npm run start:dev
```

**Services:**
- API:          http://localhost:3000/api/v1
- Swagger:      http://localhost:3000/docs
- pgAdmin:      http://localhost:5050 (admin@freight.local / admin)
- Redis UI:     http://localhost:8081

---

## API Contract

```jsonc
// Success
{ "success": true, "data": {}, "meta": { "page": 1, "limit": 20, "total": 143, "totalPages": 8 } }

// Error
{ "success": false, "error": { "code": "VALIDATION_ERROR", "message": "...", "details": [] } }
```

Pagination: `?page=1&limit=20&sortBy=created_at&sortOrder=desc`  
Dates: ISO 8601 (`YYYY-MM-DDTHH:mm:ssZ`)  
Currency: `Decimal` stored in DB, formatted at display layer

---

## Module Progress

- [x] Week 0 — Infrastructure, Docker, Prisma, RLS, Master Data schemas
- [ ] Week 1 — Auth + RBAC + Login Security
- [ ] Week 2 — User Management + Party Master
- [ ] Week 3 — Quotation Module
- [ ] Week 4–6 — Air Export Operations
- [ ] Week 7–8 — Sea FCL Export Operations
- [ ] Week 9 — Sea FCL Import Operations
- [ ] Week 10–12 — Finance + Accounting
