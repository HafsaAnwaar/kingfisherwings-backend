/* eslint-disable @typescript-eslint/no-explicit-any */
import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface PaginatedData {
  items: any[];
  total: number;
  page: number;
  limit: number;
}

@Injectable()
export class ResponseInterceptor implements NestInterceptor {
  intercept(_ctx: ExecutionContext, next: CallHandler): Observable<any> {
    return next.handle().pipe(
      map((data) => {
        if (this.isPaginated(data)) {
          const { items, total, page, limit } = data as PaginatedData;
          return {
            success: true,
            data: items,
            meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
          };
        }
        return { success: true, data };
      }),
    );
  }

  private isPaginated(d: any): boolean {
    return d && typeof d === 'object' && 'items' in d && 'total' in d && 'page' in d;
  }
}
