-- ─────────────────────────────────────────────────────────────
-- MIGRATION 0000_init
-- Enables extensions + RLS on every tenant-scoped table
-- ─────────────────────────────────────────────────────────────

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- RLS context helpers
CREATE OR REPLACE FUNCTION current_tenant_id()
RETURNS UUID LANGUAGE sql STABLE AS $$
  SELECT current_setting('app.tenant_id', TRUE)::UUID
$$;

CREATE OR REPLACE FUNCTION set_tenant_context(p_tenant_id UUID)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  PERFORM set_config('app.tenant_id', p_tenant_id::TEXT, TRUE);
END;
$$;

-- ── RLS macro: enable + create isolation policy ───────────────
-- Called once per table after table creation
-- Usage: SELECT enable_rls_for_table('table_name');
CREATE OR REPLACE FUNCTION enable_rls_for_table(p_table TEXT)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', p_table);
  EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', p_table);
  EXECUTE format(
    'CREATE POLICY tenant_isolation ON %I
       USING (tenant_id = current_tenant_id())
       WITH CHECK (tenant_id = current_tenant_id())',
    p_table
  );
END;
$$;

-- ── Apply RLS to every tenant-scoped table ────────────────────
SELECT enable_rls_for_table('users');
SELECT enable_rls_for_table('branches');
SELECT enable_rls_for_table('countries');
SELECT enable_rls_for_table('currencies');
SELECT enable_rls_for_table('exchange_rates');
SELECT enable_rls_for_table('ports');
SELECT enable_rls_for_table('airports');
SELECT enable_rls_for_table('airlines');
SELECT enable_rls_for_table('shipping_lines');
SELECT enable_rls_for_table('vessels');
SELECT enable_rls_for_table('container_types');
SELECT enable_rls_for_table('charge_codes');
SELECT enable_rls_for_table('hs_codes');
SELECT enable_rls_for_table('tax_rates');
SELECT enable_rls_for_table('departments');
SELECT enable_rls_for_table('designations');
SELECT enable_rls_for_table('banks');
SELECT enable_rls_for_table('holidays');
SELECT enable_rls_for_table('units_of_measure');
SELECT enable_rls_for_table('truckers');
SELECT enable_rls_for_table('cfs_port_agents');
SELECT enable_rls_for_table('customs_brokers');
SELECT enable_rls_for_table('warehouses');
SELECT enable_rls_for_table('products');
SELECT enable_rls_for_table('jobs');
SELECT enable_rls_for_table('air_job_details');
SELECT enable_rls_for_table('sea_fcl_job_details');
SELECT enable_rls_for_table('job_containers');
SELECT enable_rls_for_table('job_charges');
SELECT enable_rls_for_table('job_milestones');
SELECT enable_rls_for_table('job_documents');
SELECT enable_rls_for_table('job_notes');
SELECT enable_rls_for_table('audit_logs');

-- NOTE: 'tenants' table intentionally excluded — no RLS,
-- it IS the tenant root and is accessed by SUPER_ADMIN only
